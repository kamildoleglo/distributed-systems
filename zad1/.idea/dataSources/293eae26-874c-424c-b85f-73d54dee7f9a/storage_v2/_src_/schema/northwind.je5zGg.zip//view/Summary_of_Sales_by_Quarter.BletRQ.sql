create definer = root@localhost view `Summary of Sales by Quarter` as
select `northwind`.`Orders`.`ShippedDate` AS `ShippedDate`,
       `northwind`.`Orders`.`OrderID`     AS `OrderID`,
       `Order Subtotals`.`Subtotal`       AS `Subtotal`
from (`northwind`.`Orders`
       join `northwind`.`Order Subtotals` on (`northwind`.`Orders`.`OrderID` = `Order Subtotals`.`OrderID`))
where `northwind`.`Orders`.`ShippedDate` is not null;

