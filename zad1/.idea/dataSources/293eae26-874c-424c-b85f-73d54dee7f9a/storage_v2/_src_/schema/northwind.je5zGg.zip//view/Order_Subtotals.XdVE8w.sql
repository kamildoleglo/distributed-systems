create definer = root@localhost view `Order Subtotals` as
select `northwind`.`Order Details`.`OrderID`                         AS `OrderID`,
       sum(`northwind`.`Order Details`.`UnitPrice` * `northwind`.`Order Details`.`Quantity` *
           (1 - `northwind`.`Order Details`.`Discount`) / 100 * 100) AS `Subtotal`
from `northwind`.`Order Details`
group by `northwind`.`Order Details`.`OrderID`;

