create definer = root@localhost view `Alphabetical list of products` as
select `northwind`.`Products`.`ProductID`       AS `ProductID`,
       `northwind`.`Products`.`ProductName`     AS `ProductName`,
       `northwind`.`Products`.`SupplierID`      AS `SupplierID`,
       `northwind`.`Products`.`CategoryID`      AS `CategoryID`,
       `northwind`.`Products`.`QuantityPerUnit` AS `QuantityPerUnit`,
       `northwind`.`Products`.`UnitPrice`       AS `UnitPrice`,
       `northwind`.`Products`.`UnitsInStock`    AS `UnitsInStock`,
       `northwind`.`Products`.`UnitsOnOrder`    AS `UnitsOnOrder`,
       `northwind`.`Products`.`ReorderLevel`    AS `ReorderLevel`,
       `northwind`.`Products`.`Discontinued`    AS `Discontinued`,
       `northwind`.`Categories`.`CategoryName`  AS `CategoryName`
from (`northwind`.`Categories`
       join `northwind`.`Products` on (`northwind`.`Categories`.`CategoryID` = `northwind`.`Products`.`CategoryID`))
where `northwind`.`Products`.`Discontinued` = 0;

