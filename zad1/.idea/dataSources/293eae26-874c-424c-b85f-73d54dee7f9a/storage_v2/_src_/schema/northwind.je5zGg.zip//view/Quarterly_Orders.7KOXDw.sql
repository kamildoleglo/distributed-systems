create definer = root@localhost view `Quarterly Orders` as
select distinct `northwind`.`Customers`.`CustomerID`  AS `CustomerID`,
                `northwind`.`Customers`.`CompanyName` AS `CompanyName`,
                `northwind`.`Customers`.`City`        AS `City`,
                `northwind`.`Customers`.`Country`     AS `Country`
from (`northwind`.`Customers`
       join `northwind`.`Orders` on (`northwind`.`Customers`.`CustomerID` = `northwind`.`Orders`.`CustomerID`))
where `northwind`.`Orders`.`OrderDate` between '1997-01-01' and '1997-12-31';

