create definer = root@localhost view Invoices as
select `northwind`.`Orders`.`ShipName`                                                AS `ShipName`,
       `northwind`.`Orders`.`ShipAddress`                                             AS `ShipAddress`,
       `northwind`.`Orders`.`ShipCity`                                                AS `ShipCity`,
       `northwind`.`Orders`.`ShipRegion`                                              AS `ShipRegion`,
       `northwind`.`Orders`.`ShipPostalCode`                                          AS `ShipPostalCode`,
       `northwind`.`Orders`.`ShipCountry`                                             AS `ShipCountry`,
       `northwind`.`Orders`.`CustomerID`                                              AS `CustomerID`,
       `northwind`.`Customers`.`CompanyName`                                          AS `CustomerName`,
       `northwind`.`Customers`.`Address`                                              AS `Address`,
       `northwind`.`Customers`.`City`                                                 AS `City`,
       `northwind`.`Customers`.`Region`                                               AS `Region`,
       `northwind`.`Customers`.`PostalCode`                                           AS `PostalCode`,
       `northwind`.`Customers`.`Country`                                              AS `Country`,
       `northwind`.`Employees`.`FirstName` + ' ' + `northwind`.`Employees`.`LastName` AS `Salesperson`,
       `northwind`.`Orders`.`OrderID`                                                 AS `OrderID`,
       `northwind`.`Orders`.`OrderDate`                                               AS `OrderDate`,
       `northwind`.`Orders`.`RequiredDate`                                            AS `RequiredDate`,
       `northwind`.`Orders`.`ShippedDate`                                             AS `ShippedDate`,
       `northwind`.`Shippers`.`CompanyName`                                           AS `ShipperName`,
       `northwind`.`Order Details`.`ProductID`                                        AS `ProductID`,
       `northwind`.`Products`.`ProductName`                                           AS `ProductName`,
       `northwind`.`Order Details`.`UnitPrice`                                        AS `UnitPrice`,
       `northwind`.`Order Details`.`Quantity`                                         AS `Quantity`,
       `northwind`.`Order Details`.`Discount`                                         AS `Discount`,
       `northwind`.`Order Details`.`UnitPrice` * `northwind`.`Order Details`.`Quantity` *
       (1 - `northwind`.`Order Details`.`Discount`) / 100 * 100                       AS `ExtendedPrice`,
       `northwind`.`Orders`.`Freight`                                                 AS `Freight`
from (((((`northwind`.`Customers` join `northwind`.`Orders` on (`northwind`.`Customers`.`CustomerID` =
                                                                `northwind`.`Orders`.`CustomerID`)) join `northwind`.`Employees` on (
    `northwind`.`Employees`.`EmployeeID` = `northwind`.`Orders`.`EmployeeID`)) join `northwind`.`Order Details` on (
    `northwind`.`Orders`.`OrderID` = `northwind`.`Order Details`.`OrderID`)) join `northwind`.`Products` on (
    `northwind`.`Products`.`ProductID` = `northwind`.`Order Details`.`ProductID`))
       join `northwind`.`Shippers` on (`northwind`.`Shippers`.`ShipperID` = `northwind`.`Orders`.`ShipVia`));

