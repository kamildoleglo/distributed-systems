create definer = root@localhost view `Products Above Average Price` as
select `northwind`.`Products`.`ProductName` AS `ProductName`, `northwind`.`Products`.`UnitPrice` AS `UnitPrice`
from `northwind`.`Products`
where `northwind`.`Products`.`UnitPrice` > (select avg(`northwind`.`Products`.`UnitPrice`) from `northwind`.`Products`);

